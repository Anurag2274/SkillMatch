import CustomFunctionAction from "./CustomFunctionAction.js";
declare class RemoteAction extends CustomFunctionAction {
    constructor(fn: string);
    preprocess(): this;
}
export default RemoteAction;
