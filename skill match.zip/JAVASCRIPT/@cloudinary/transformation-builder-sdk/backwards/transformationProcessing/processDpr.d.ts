/**
 * Process DPR value. If input is 1 returns 1.0
 * @param value
 */
export declare function processDpr(value: string | number): string | number;
