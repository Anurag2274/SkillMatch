export declare function textStyle(layer: any): string;
export declare function processLayer(layer: any): string;
