/**
 *
 * @param a
 */
export declare function isObject(a: any): a is Record<string, any>;
