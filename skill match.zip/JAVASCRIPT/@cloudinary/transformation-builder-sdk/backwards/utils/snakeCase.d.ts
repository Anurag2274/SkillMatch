/**
 * Converts string to snake case
 * @param {string} str
 */
export declare const snakeCase: (str: string) => string;
