export declare function isEmpty(value: any): boolean;
