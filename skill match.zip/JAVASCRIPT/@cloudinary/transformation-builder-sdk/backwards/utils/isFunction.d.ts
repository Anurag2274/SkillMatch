/**
 * Simple Is Function check
 *
 * @param variableToCheck
 * @returns {boolean}
 */
export declare function isFunction(variableToCheck: any): boolean;
