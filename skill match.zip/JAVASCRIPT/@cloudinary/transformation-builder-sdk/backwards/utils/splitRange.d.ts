export declare function splitRange(range: any): any;
