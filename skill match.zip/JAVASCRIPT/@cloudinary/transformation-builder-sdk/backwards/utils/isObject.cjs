'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 *
 * @param a
 */
function isObject(a) {
    return typeof a === 'object' && a !== null;
}

exports.isObject = isObject;
