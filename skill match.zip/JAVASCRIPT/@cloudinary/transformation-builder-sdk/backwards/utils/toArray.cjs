'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 *
 * @param arg
 */
function toArray(arg) {
    switch (true) {
        case arg == null:
            return [];
        case Array.isArray(arg):
            return arg;
        default:
            return [arg];
    }
}

exports.toArray = toArray;
