/**
 *
 * @param arg
 */
export declare function toArray(arg: any): any;
