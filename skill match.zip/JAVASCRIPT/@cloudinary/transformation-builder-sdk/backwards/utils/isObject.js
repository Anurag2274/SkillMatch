/**
 *
 * @param a
 */
export function isObject(a) {
    return typeof a === 'object' && a !== null;
}
