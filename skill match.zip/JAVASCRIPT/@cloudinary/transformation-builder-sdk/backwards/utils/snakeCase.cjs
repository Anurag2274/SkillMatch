'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * Converts string to snake case
 * @param {string} str
 */
var snakeCase = function (str) { return str.replace(/[A-Z]/g, function (letter) { return "_" + letter.toLowerCase(); }); };

exports.snakeCase = snakeCase;
