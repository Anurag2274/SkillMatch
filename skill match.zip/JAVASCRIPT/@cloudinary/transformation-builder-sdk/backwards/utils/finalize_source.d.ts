export declare function finalize_source(source: string, format: string, url_suffix: string): string[];
