export declare function smartEscape(string: string, unsafe?: RegExp): string;
