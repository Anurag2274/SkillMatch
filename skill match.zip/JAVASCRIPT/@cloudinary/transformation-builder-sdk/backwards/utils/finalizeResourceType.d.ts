export declare function finalize_resource_type(resource_type: string, type: string, url_suffix: string, use_root_path: boolean, shorten: boolean): string[];
