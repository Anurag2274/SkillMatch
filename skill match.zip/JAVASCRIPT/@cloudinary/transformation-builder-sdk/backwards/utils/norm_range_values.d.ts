import { stringOrNumber } from "../../types/types.js";
/**
 *
 * @param value
 */
export declare function normRangeValues(value: stringOrNumber): string | number;
