'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * Simple Is Function check
 *
 * @param variableToCheck
 * @returns {boolean}
 */
function isFunction(variableToCheck) {
    return variableToCheck instanceof Function;
}

exports.isFunction = isFunction;
