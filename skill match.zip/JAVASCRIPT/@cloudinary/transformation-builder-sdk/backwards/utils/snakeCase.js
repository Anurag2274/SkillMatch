/**
 * Converts string to snake case
 * @param {string} str
 */
export const snakeCase = (str) => str.replace(/[A-Z]/g, letter => `_${letter.toLowerCase()}`);
