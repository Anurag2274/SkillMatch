/**
 * Simple Is Function check
 *
 * @param variableToCheck
 * @returns {boolean}
 */
export function isFunction(variableToCheck) {
    return variableToCheck instanceof Function;
}
