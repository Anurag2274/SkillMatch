import { LegacyITransforamtionOptions } from "../types/types.js";
export declare function createCloudinaryLegacyURL(public_id: string, transformationOptions: LegacyITransforamtionOptions): string;
