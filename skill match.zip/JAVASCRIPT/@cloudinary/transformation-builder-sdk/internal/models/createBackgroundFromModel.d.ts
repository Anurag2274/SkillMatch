import { BackgroundQualifier } from "../../qualifiers/background/shared/base/BackgroundQualifier.js";
import { IBackgroundModel } from "./createBackgroundModel.js";
/**
 * Create BackgroundQualifier from IBackgroundModel
 * @param backgroundModel
 */
declare function createBackgroundFromModel(backgroundModel: IBackgroundModel): BackgroundQualifier;
export { createBackgroundFromModel };
