import { IPositionModel } from "./IPositionModel.js";
import { Position } from "../../qualifiers/position.js";
/**
 * Create Position from given IPositionModel
 * @param position
 */
export declare function createPositionFromModel(position: IPositionModel): Position;
