import { IActionModel } from "./IActionModel.js";
interface ImproveActionModel extends IActionModel {
    mode?: string;
    blend?: number;
}
export { ImproveActionModel };
