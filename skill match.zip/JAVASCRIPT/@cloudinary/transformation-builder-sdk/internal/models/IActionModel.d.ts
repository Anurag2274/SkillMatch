interface IActionModel {
    actionType?: string;
    [x: string]: unknown;
}
/**
 * Validates obj is an instance of IActionModel
 * @param obj
 */
declare function isIActionModel(obj: unknown): obj is IActionModel;
export { IActionModel, isIActionModel };
