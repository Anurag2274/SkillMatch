'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

var internal_models_actionToJson = require('./actionToJson.cjs');
require('../utils/unsupportedError.cjs');
require('../../tslib.es6-7a681263.cjs');

var ActionModel = /** @class */ (function () {
    function ActionModel() {
        this._actionModel = {};
    }
    ActionModel.prototype.toJson = function () {
        return internal_models_actionToJson.actionToJson.apply(this);
    };
    return ActionModel;
}());

exports.ActionModel = ActionModel;
