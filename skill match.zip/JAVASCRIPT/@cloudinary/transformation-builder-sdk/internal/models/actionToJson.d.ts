import { IActionModel } from "./IActionModel.js";
import { IErrorObject } from "./IErrorObject.js";
export declare type IActionToJson = IActionModel | IErrorObject;
/**
 * Returns the action's model
 */
export declare function actionToJson(): IActionToJson;
