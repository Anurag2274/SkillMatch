'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

/**
 * Validates obj is an instance of IActionModel
 * @param obj
 */
function isIActionModel(obj) {
    var actionModel = obj;
    return ('actionType' in actionModel);
}

exports.isIActionModel = isIActionModel;
