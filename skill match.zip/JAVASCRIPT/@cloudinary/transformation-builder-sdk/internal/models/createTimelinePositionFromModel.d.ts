import { ITimelinePositionModel } from "./ITimelinePositionModel.js";
import { TimelinePosition } from "../../qualifiers/video/TimelinePosition.js";
/**
 * Create TimelinePosition from given ITimelinePositionModel
 * @param timelinePosition
 */
export declare function createTimelinePositionFromModel(timelinePosition: ITimelinePositionModel): TimelinePosition;
