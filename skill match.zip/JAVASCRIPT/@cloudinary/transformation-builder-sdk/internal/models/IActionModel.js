/**
 * Validates obj is an instance of IActionModel
 * @param obj
 */
function isIActionModel(obj) {
    const actionModel = obj;
    return ('actionType' in actionModel);
}
export { isIActionModel };
