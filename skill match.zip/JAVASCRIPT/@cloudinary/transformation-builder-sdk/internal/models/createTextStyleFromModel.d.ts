import { ITextStyleModel } from "./ITextStyleModel.js";
import { TextStyle } from "../../qualifiers/textStyle.js";
/**
 * Create TextStyle from ITextStyleModel
 * @param textStyleModel
 */
export declare function createTextStyleFromModel(textStyleModel: ITextStyleModel): TextStyle;
