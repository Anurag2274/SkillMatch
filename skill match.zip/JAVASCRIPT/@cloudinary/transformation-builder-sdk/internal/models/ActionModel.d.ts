import { IActionModel } from "./IActionModel.js";
import { actionToJson } from "./actionToJson.js";
export declare class ActionModel {
    protected _actionModel: IActionModel;
    constructor();
    toJson(): typeof actionToJson;
}
