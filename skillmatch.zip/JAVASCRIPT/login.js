import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword,signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
const firebaseConfig = {
  apiKey: "AIzaSyDpgl6qecUYKgkHyNkxFOPwOoSzuGcsuDg",
  authDomain: "unknown-ce23e.firebaseapp.com",
  projectId: "unknown-ce23e",
  storageBucket: "unknown-ce23e.firebasestorage.app",
  messagingSenderId: "353269494428",
  appId: "1:353269494428:web:8da2e77318ad15e249f359"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth()
const submit=document.getElementsByClassName("submit")[0];
submit.addEventListener('click',(e)=>{
  e.preventDefault();
 const email = document.getElementById("name").value ;
 const password = document.getElementById("password").value ;
  signInWithEmailAndPassword(auth,email ,password)
  .then(alert("login succesful"))
  .catch((error)=>{
    alert(error);
  })
})