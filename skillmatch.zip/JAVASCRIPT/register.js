
// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore,setDoc,doc } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
// import{getStorage,rref,uploadBytesResumable,getDownloadURL} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-storage.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDpgl6qecUYKgkHyNkxFOPwOoSzuGcsuDg",
  authDomain: "unknown-ce23e.firebaseapp.com",
  projectId: "unknown-ce23e",
  storageBucket: "unknown-ce23e.firebasestorage.app",
  messagingSenderId: "353269494428",
  appId: "1:353269494428:web:8da2e77318ad15e249f359"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

const register = document.getElementsByClassName("submit");
register[0].addEventListener('click', (event) => {
  event.preventDefault();

  const Email = document.getElementById("name").value;
  const Password = document.getElementById("password").value;
 const  username= document.getElementById("username").value;
  const discption= document.getElementsByClassName("description")[0].value;
  const contact= document.getElementsByClassName("contact")[0].value;
 const  skill= document.getElementById("skill").value;
 const project= document.getElementById("project").value;
 const projectDiscription=document.getElementById("projectdiscription").value;
 const help=document.getElementById("skillhelp").value;
  const auth = getAuth();
  const db = getFirestore();
  createUserWithEmailAndPassword(auth, Email, Password)
    .then((userCredential) => {
      
      const user = userCredential.user;
      const userData = {
        Email: Email,
        username:username,
        discption:discption,
        contact:contact,
        skill:skill,
        project:project,
        projectDiscription:projectDiscription,
        help:help
      };
      alert("Creating New Account");
      const docRef = doc(db,"users",username);
      setDoc(docRef,userData)
      .then(()=>{
         console.log("correct");
      })
      .catch((error)=>{
        console.log(error);
      })
    })
    .catch((error) => {
      const errorCode = error.code;
      const errorMessage = error.message;
      // ..
      alert(errorMessage);
    });

})


