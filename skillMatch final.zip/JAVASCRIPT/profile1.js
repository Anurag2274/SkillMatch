import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth, createUserWithEmailAndPassword,signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore,setDoc,doc,getDoc,getDocs,onSnapshot, collection } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
import{uname}from "./login.js"
const firebaseConfig = {
  apiKey: "AIzaSyDpgl6qecUYKgkHyNkxFOPwOoSzuGcsuDg",
  authDomain: "unknown-ce23e.firebaseapp.com",
  projectId: "unknown-ce23e",
  storageBucket: "unknown-ce23e.firebasestorage.app",
  messagingSenderId: "353269494428",
  appId: "1:353269494428:web:8da2e77318ad15e249f359"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth()
const db = getFirestore();

const docRef = doc(db,"users",uname);
const docSnap =  await getDoc(docRef);

console.log(docSnap.data())



document.getElementsByClassName("name")[0].innerHTML=docSnap.data().username;
document.getElementsByClassName("profession")[0].innerHTML=docSnap.data().profession;
document.getElementsByClassName("skill")[0].innerHTML=docSnap.data().skill;
document.getElementsByClassName("photo")[0].src = docSnap.data().image;



const search = document.getElementById("search");
const table =  document.getElementById("table") ;
const AddTable = () => {
    table.style.display = 'block';
}

const removeTable = () =>{
  table.style.display = 'none';
}
setTimeout (removeTable,20);
search.addEventListener('mouseover',AddTable);
table.addEventListener('mouseover',AddTable);
search.addEventListener('mouseout',removeTable);
table.addEventListener('mouseout',removeTable);



document.getElementsByClassName("logout")[0].addEventListener('click',()=>{
  window.location.href = "../HTML/index.html";
})
