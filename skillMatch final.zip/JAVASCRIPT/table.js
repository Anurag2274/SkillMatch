import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore,doc,getDocs ,onSnapshot, collection } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
// import{getName}from "./login"

const firebaseConfig = {
  apiKey: "AIzaSyDpgl6qecUYKgkHyNkxFOPwOoSzuGcsuDg",
  authDomain: "unknown-ce23e.firebaseapp.com",
  projectId: "unknown-ce23e",
  storageBucket: "unknown-ce23e.firebasestorage.app",
  messagingSenderId: "353269494428",
  appId: "1:353269494428:web:8da2e77318ad15e249f359"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth()
const db = getFirestore();
let number = 0;
var tbody = document.getElementById("tbody1");

const AddSingleRecord = (username, skill, contact, avalibility) => {
  let trow = document.createElement('tr'); 
  let td1 = document.createElement("td");
  let td2 = document.createElement("td");
  let td3 = document.createElement("td");
  let td4 = document.createElement("td");
  let td5 = document.createElement("td");

  td1.innerHTML = ++number;
  td2.innerHTML = username;
  td3.innerHTML = skill;
  td4.innerHTML = contact;
  td5.innerHTML = avalibility;

  trow.appendChild(td1);
  trow.appendChild(td2);
  trow.appendChild(td3);
  trow.appendChild(td4);
  trow.appendChild(td5);
  tbody.appendChild(trow); 
}

function AddAllItemsToTable(users) {
  number = 0;
  tbody.innerHTML = "";
  users.forEach(user => {
    AddSingleRecord(user.username, user.skill, user.contact, user.avalibility); 
  });
}

async function GetAllDataOnce() {
  const querySnapshot = await getDocs(collection(db, "users")); 
  var users = [];
  querySnapshot.forEach(doc => {
    users.push(doc.data());
  });
  AddAllItemsToTable(users);
}

async function GetAllDataRealtime() {
  const dbRef = collection(db, "users"); 
  onSnapshot(dbRef,(querySnapshot)=>{
    var users = [];
    querySnapshot.forEach(doc => {
       users.push(doc.data());
  })
   AddAllItemsToTable(users);
  })
}

window.onload = GetAllDataRealtime;





var searchbar = document.getElementById("search")


function search () {

  var orignal = tbody.innerHTML;
  tbody.innerHTML = orignal;
  let rows = tbody.children;
  if(searchbar.value.length < 1){
    return;
  }
  let filter = "";
  let searchtext = searchbar.value.toLowerCase();
  
  for(let i=0;i<rows.length;i++){
    const currentrow = rows[i].children[2].innerText.toLowerCase();
    if(currentrow.indexOf(searchtext) > -1){
      filter += rows[i].outerHTML;
    }
    
  }
  console.log(rows[0])
  tbody.innerHTML = filter;  
}
searchbar.addEventListener('input',search);
  