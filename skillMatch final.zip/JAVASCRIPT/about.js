import { initializeApp } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.1.0/firebase-auth.js";
import { getFirestore,doc,getDoc ,updateDoc} from "https://www.gstatic.com/firebasejs/11.1.0/firebase-firestore.js";
import{uname}from "./login.js"

const firebaseConfig = {
  apiKey: "AIzaSyDpgl6qecUYKgkHyNkxFOPwOoSzuGcsuDg",
  authDomain: "unknown-ce23e.firebaseapp.com",
  projectId: "unknown-ce23e",
  storageBucket: "unknown-ce23e.firebasestorage.app",
  messagingSenderId: "353269494428",
  appId: "1:353269494428:web:8da2e77318ad15e249f359"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth()

const db = getFirestore();

const docRef = doc(db,"users",uname);
   const docSnap =  await getDoc(docRef);
    
 

document.getElementsByClassName("circle")[0].addEventListener('click', async (e) => {
  e.preventDefault();
  
  try {
    const userData = {
      
      avalibility: !(docSnap.data().avalibility)
    };
    alert("Updating availability...");
    
    await updateDoc(docRef, userData);

    // Fetch the updated document to log the new availability status
    var updatedDocSnap = await getDoc(docRef);
    console.log("Updated availability:", updatedDocSnap.data().avalibility);
    if(updatedDocSnap.data().avalibility == true){
      document.getElementsByClassName("circle")[0].style.justifyContent = 'end';
    }
    else{
      document.getElementsByClassName("circle")[0].style.justifyContent = 'start';
    }
     
  } catch (error) {
    console.error("Error updating document:", error);
  }
})
 







document.getElementById("name").innerHTML = docSnap.data().username;
document.getElementById("profession").innerHTML = docSnap.data().profession;
document.getElementById("skill").innerHTML = docSnap.data().skill;
document.getElementById("aboutdiscription").innerHTML = docSnap.data().discption;
document.getElementById("aboutskilldiscription").innerHTML = docSnap.data().projectDiscription;
document.getElementById("project").innerHTML = docSnap.data().project;
document.getElementById("photo").src = docSnap.data().image;
  

if(docSnap.data().avalibility == true){
  document.getElementsByClassName("circle")[0].style.justifyContent = 'end';

}

document.getElementsByClassName("logout")[0].addEventListener('click',()=>{
  window.location.href = "../HTML/index.html";
})

